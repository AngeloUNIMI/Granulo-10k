def pause():
    input("paused...")
